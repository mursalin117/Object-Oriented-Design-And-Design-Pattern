public abstract class NotificationFactory {
    abstract Notification createNotification(String notificationType) ;
}
