public class Robot {
    public void walkForward(){
        System.out.println("Robot: walk forward");
    }
    public void stop(){
        System.out.println("Robot: stop");
    }
    public void turnLeft(){
        System.out.println("Robot: turn left");
    }
    public void turnRight(){
        System.out.println("Robot: turn right");
    }
    public void goBackward(){
        System.out.println("Robot: go back backward");
    }
}